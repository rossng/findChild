<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Copyright (c) 2011 Ross Gardiner

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => 'findChild

Find a child of the current page with a particular property/value pair
and return one of its other properties.

@author Ross Gardiner
@copyright MIT License Ross Gardiner 2010
@version 1.0-beta - January 15, 2011

OPTIONS

$property, $value - Property/value pair to find child page with.
$return - Property of child page to return. Can be any resource property or \'url\'.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '37f1a89402e51616c690f73e6f7e8506',
      'native_key' => 'findchild',
      'filename' => 'modNamespace/b3492e17d6ed59018335a936f7e05b81.vehicle',
      'namespace' => 'findchild',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a6ad9964255f0a46b985b0cd9f7d383',
      'native_key' => 1,
      'filename' => 'modCategory/d56e8606400018bd0db537bd80e08958.vehicle',
      'namespace' => 'findchild',
    ),
  ),
);